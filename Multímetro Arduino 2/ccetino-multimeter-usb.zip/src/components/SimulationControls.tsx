import React from 'react';
import { Sliders, Zap, Wifi, AlertTriangle, Sparkles, RefreshCw } from 'lucide-react';

interface SimulationControlsProps {
  simNominal: number;
  setSimNominal: (val: number) => void;
  simMax: number;
  setSimMax: (val: number) => void;
  simMode: 'AC' | 'DC';
  setSimMode: (val: 'AC' | 'DC') => void;
  simFluctuation: 'none' | 'low' | 'high';
  setSimFluctuation: (val: 'none' | 'low' | 'high') => void;
  onTriggerSpike: () => void;
  onTriggerDrop: () => void;
  onResetStats: () => void;
}

export default function SimulationControls({
  simNominal,
  setSimNominal,
  simMax,
  setSimMax,
  simMode,
  setSimMode,
  simFluctuation,
  setSimFluctuation,
  onTriggerSpike,
  onTriggerDrop,
  onResetStats
}: SimulationControlsProps) {
  return (
    <div className="glass-panel p-6 flex flex-col h-full overflow-hidden">
      <div className="flex justify-between items-center mb-6">
        <div>
          <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block mb-1">
            Configuração // painel_simulador
          </span>
          <h2 className="font-display text-xl font-semibold text-white">Configurar Simulação da Porta Serial</h2>
        </div>
        <div className="flex items-center gap-2 bg-purple-950/20 border border-purple-500/20 px-3 py-1.5 rounded font-mono text-xs text-purple-300">
          <Sliders className="w-3.5 h-3.5 text-purple-400" />
          <span>Simulador Inteligente Ativo</span>
        </div>
      </div>

      <p className="text-sm text-neutral-300 mb-6 font-sans">
        Abaixo, você pode ajustar as variáveis do sinal simulado. O simulador gera leituras contínuas (que imitam perfeitamente a porta serial USB do Raspberry Pi Pico) para permitir o desenvolvimento visual e testes de limites sem precisar do hardware conectado física ou diretamente neste instante.
      </p>

      {/* Inputs Form */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Nominal Target Voltage */}
        <div className="flex flex-col gap-2">
          <label className="font-mono text-[11px] text-neutral-400 uppercase tracking-wider">
            Tensão Nominal de Trabalho (V)
          </label>
          <input
            id="input-sim-nominal"
            type="number"
            min="1"
            max="290"
            value={simNominal}
            onChange={(e) => setSimNominal(Math.min(290, Math.max(1, parseInt(e.target.value) || 220)))}
            className="bg-neutral-900 border border-white/10 rounded px-3 py-2 font-mono text-cyan-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all text-sm"
          />
          <span className="text-[10px] text-neutral-500 italic">Padrões comuns no Brasil: 127V, 220V ou 12V em baterias.</span>
        </div>

        {/* Max Allowed Limit */}
        <div className="flex flex-col gap-2">
          <label className="font-mono text-[11px] text-neutral-400 uppercase tracking-wider">
            Tensão Máxima de Escala (V)
          </label>
          <input
            id="input-sim-max"
            type="number"
            min="10"
            max="300"
            value={simMax}
            onChange={(e) => setSimMax(Math.min(300, Math.max(10, parseInt(e.target.value) || 300)))}
            className="bg-neutral-900 border border-white/10 rounded px-3 py-2 font-mono text-cyan-300 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all text-sm"
          />
          <span className="text-[10px] text-neutral-500 italic">Define o limite superior da escala de 0 a 300 Volts.</span>
        </div>

        {/* AC or DC toggle */}
        <div className="flex flex-col gap-2">
          <label className="font-mono text-[11px] text-neutral-400 uppercase tracking-wider">
            Tipo de Corrente (Sinal)
          </label>
          <div className="flex bg-neutral-900 border border-white/10 p-1 rounded font-mono text-xs">
            <button
              onClick={() => setSimMode('AC')}
              className={`flex-1 py-1.5 rounded transition-all text-center ${
                simMode === 'AC'
                  ? 'bg-cyan-500/15 text-cyan-400 font-bold border border-cyan-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              AC (Corrente Alternada)
            </button>
            <button
              onClick={() => setSimMode('DC')}
              className={`flex-1 py-1.5 rounded transition-all text-center ${
                simMode === 'DC'
                  ? 'bg-cyan-500/15 text-cyan-400 font-bold border border-cyan-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              DC (Corrente Contínua)
            </button>
          </div>
        </div>

        {/* Noise Fluctuation selector */}
        <div className="flex flex-col gap-2">
          <label className="font-mono text-[11px] text-neutral-400 uppercase tracking-wider">
            Oscilação de Ruído / Instabilidade
          </label>
          <div className="flex bg-neutral-900 border border-white/10 p-1 rounded font-mono text-xs">
            <button
              onClick={() => setSimFluctuation('none')}
              className={`flex-1 py-1.5 rounded transition-all text-center ${
                simFluctuation === 'none'
                  ? 'bg-cyan-500/15 text-cyan-400 font-bold border border-cyan-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Zero
            </button>
            <button
              onClick={() => setSimFluctuation('low')}
              className={`flex-1 py-1.5 rounded transition-all text-center ${
                simFluctuation === 'low'
                  ? 'bg-cyan-500/15 text-cyan-400 font-bold border border-cyan-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Mínima
            </button>
            <button
              onClick={() => setSimFluctuation('high')}
              className={`flex-1 py-1.5 rounded transition-all text-center ${
                simFluctuation === 'high'
                  ? 'bg-cyan-500/15 text-cyan-400 font-bold border border-cyan-500/20'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Máxima (Ruído)
            </button>
          </div>
        </div>
      </div>

      {/* Interactive Spike Triggers (For testing alerts) */}
      <div className="mt-auto border-t border-white/10 pt-6">
        <h3 className="font-mono text-xs text-neutral-400 uppercase tracking-wider mb-4 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          Injetor de Surtos / Falhas de Rede (Para Testes)
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Spike */}
          <button
            onClick={onTriggerSpike}
            className="bg-red-950/20 hover:bg-red-950/50 text-red-400 border border-red-500/30 hover:border-red-500 py-3 rounded text-xs font-mono font-bold tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-red-400 animate-bounce" />
            INJETAR SURTO (+25%)
          </button>

          {/* Sags / Drops */}
          <button
            onClick={onTriggerDrop}
            className="bg-yellow-950/20 hover:bg-yellow-950/50 text-yellow-400 border border-yellow-500/30 hover:border-yellow-500 py-3 rounded text-xs font-mono font-bold tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-yellow-400" />
            QUEDA DE TENSÃO (-30%)
          </button>

          {/* Reset Metrics */}
          <button
            onClick={onResetStats}
            className="bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 py-3 rounded text-xs font-mono font-bold tracking-wider flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            ZERAR MIN / MÁX / MÉDIA
          </button>
        </div>
        <p className="text-[10px] text-neutral-500 italic mt-3 text-center">
          💡 Clique em "Injetar Surto" ou "Queda de Tensão" para ver instantaneamente os alarmes piscando em vermelho na tela principal e registrando logs de eventos no painel inferior!
        </p>
      </div>
    </div>
  );
}
