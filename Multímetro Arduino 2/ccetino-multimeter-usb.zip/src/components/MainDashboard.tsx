import React from 'react';
import { Reading, Stats } from '../types';
import { 
  TrendingUp, 
  Verified, 
  BrainCircuit, 
  Radio, 
  Trash2,
  Activity,
  AlertTriangle,
  Flame,
  BatteryCharging
} from 'lucide-react';

interface MainDashboardProps {
  currentReading: Reading;
  stats: Stats;
  history: Reading[];
  onResetStats: () => void;
  nominalVoltage: number;
}

export default function MainDashboard({
  currentReading,
  stats,
  history,
  onResetStats,
  nominalVoltage
}: MainDashboardProps) {
  const { voltage, voltageMax, mode, measure, status, deviationPercent } = currentReading;

  // Percentage for the linear bar (0 to 300V scale)
  const barPercent = Math.min(100, Math.max(0, (voltage / 300) * 100));

  // Gauge needle rotation (from -90 to 90 degrees)
  const gaugePercent = Math.min(100, Math.max(0, (voltage / 300) * 100));
  const needleRotation = -90 + (gaugePercent / 100) * 180;

  // Render log lines with clean padding
  const padIndex = (idx: number) => {
    return String(idx).padStart(3, '0');
  };

  // Helper to color log entry statuses
  const getStatusColor = (st: Reading['status']) => {
    switch (st) {
      case 'SURTO_TENSÃO': return 'text-red-500 font-bold animate-pulse';
      case 'SOBRETENSÃO': return 'text-orange-400 font-bold';
      case 'SUBTENSÃO': return 'text-yellow-400';
      case 'ALERTA': return 'text-pink-400';
      default: return 'text-cyan-400/90';
    }
  };

  const getStatusBadge = (st: Reading['status']) => {
    switch (st) {
      case 'SURTO_TENSÃO': return 'bg-red-950 border border-red-500/40 text-red-400';
      case 'SOBRETENSÃO': return 'bg-orange-950 border border-orange-500/40 text-orange-400';
      case 'SUBTENSÃO': return 'bg-yellow-950 border border-yellow-500/30 text-yellow-400';
      case 'ALERTA': return 'bg-pink-950 border border-pink-500/30 text-pink-400';
      default: return 'bg-cyan-950 border border-cyan-500/20 text-cyan-400';
    }
  };

  return (
    <div className="grid grid-cols-12 gap-4 h-full">
      
      {/* 1. Large Central Voltmeter Display */}
      <section id="panel-voltmeter" className="col-span-12 lg:col-span-8 glass-panel relative flex flex-col justify-between p-6 overflow-hidden min-h-[360px]">
        {/* Decorative corner headers */}
        <div className="flex justify-between items-start">
          <div>
            <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block mb-0.5">
              Canal Eletrônica e Tecnologia
            </span>
            <div className="flex items-center gap-2 text-neutral-400 font-mono text-[11px]">
              <Activity className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span>MEDIDOR DE {measure.toUpperCase()} EM TEMPO REAL</span>
            </div>
          </div>

          {/* Configuration Badges */}
          <div className="flex gap-2 font-mono text-[10px] tracking-wider">
            <span className="relative border border-cyan-500/30 px-2 py-0.5 rounded text-cyan-400 overflow-hidden bg-cyan-950/20">
              <span className="scan-line"></span>
              AUTO_RANGE
            </span>
            <span className="border border-purple-500/40 px-2 py-0.5 rounded text-purple-400 bg-purple-950/20 font-bold uppercase">
              {mode}_MODE
            </span>
            <span className={`border px-2 py-0.5 rounded text-xs font-bold uppercase ${
              status === 'SURTO_TENSÃO' 
                ? 'border-red-500 text-red-500 bg-red-950 animate-pulse'
                : status === 'SOBRETENSÃO'
                  ? 'border-orange-500 text-orange-400 bg-orange-950'
                  : 'border-emerald-500/40 text-emerald-400 bg-emerald-950/20'
            }`}>
              {status}
            </span>
          </div>
        </div>

        {/* Huge Digital Voltage Display */}
        <div className="my-auto flex flex-col items-center justify-center relative">
          {/* Subtle glowing halo behind voltage text */}
          <div className={`absolute w-72 h-32 rounded-full blur-[60px] opacity-15 pointer-events-none transition-colors duration-500 ${
            status === 'SURTO_TENSÃO' ? 'bg-red-500' : 'bg-cyan-400'
          }`} />

          <div className="flex items-baseline gap-4 relative z-10">
            <span className={`font-display font-bold text-8xl tracking-tighter transition-all duration-100 ${
              status === 'SURTO_TENSÃO' 
                ? 'text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.5)] animate-pulse' 
                : 'text-cyan-400 glow-text-cyan'
            }`}>
              {voltage.toFixed(1)}
            </span>
            <span className="font-display font-semibold text-5xl text-neutral-400/90 tracking-tight">
              V
            </span>
          </div>
          
          <div className="font-mono text-xs text-neutral-400 mt-2 flex items-center gap-2">
            <span>TENSÃO NOMINAL DE COMPARAÇÃO:</span>
            <span className="text-white font-bold px-1.5 py-0.5 bg-neutral-900 border border-neutral-800 rounded">
              {nominalVoltage} V
            </span>
            {voltage > 0.5 && (
              <span className={`font-bold ${deviationPercent >= 0 ? 'text-red-400' : 'text-cyan-400'}`}>
                ({deviationPercent >= 0 ? '+' : ''}{deviationPercent}%)
              </span>
            )}
          </div>
        </div>

        {/* Lower horizontal linear gauge scale */}
        <div className="w-full mt-auto pt-4 border-t border-white/5">
          <div className="relative h-2.5 bg-neutral-900 border border-white/10 rounded overflow-hidden">
            <div 
              className={`h-full transition-all duration-100 ease-out shadow-[0_0_10px_rgba(0,242,255,0.4)] ${
                status === 'SURTO_TENSÃO'
                  ? 'bg-gradient-to-r from-red-600 to-red-400 shadow-red-500/50'
                  : 'bg-gradient-to-r from-cyan-500 via-cyan-400 to-purple-500'
              }`}
              style={{ width: `${barPercent}%` }}
            />
          </div>
          <div className="flex justify-between mt-1.5 font-mono text-[10px] text-neutral-500">
            <span className="flex flex-col items-start">
              <span className="w-0.5 h-1 bg-neutral-700 mb-0.5"></span>
              <span>0V</span>
            </span>
            <span className="flex flex-col items-center">
              <span className="w-0.5 h-1 bg-neutral-700 mb-0.5"></span>
              <span>150V</span>
            </span>
            <span className="flex flex-col items-end">
              <span className="w-0.5 h-1 bg-neutral-700 mb-0.5"></span>
              <span>300V</span>
            </span>
          </div>
        </div>
      </section>

      {/* 2. STATS_CONTROL Panel (Right Column) */}
      <section id="panel-stats" className="col-span-12 lg:col-span-4 glass-panel p-6 flex flex-col justify-between min-h-[360px]">
        <div>
          <div className="flex justify-between items-center mb-5 pb-3 border-b border-white/5">
            <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest flex items-center gap-1">
              SEC_02 // STATS_CONTROL
            </span>
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
          </div>

          <div className="flex flex-col gap-4">
            {/* MIN_READING */}
            <div className="bg-neutral-900/40 border border-white/5 p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-mono text-[10px] text-neutral-400 block uppercase tracking-wider">Mínimo Registrado</span>
                <span className="font-sans text-xs text-neutral-500">Mínimo lido desde o início</span>
              </div>
              <div className="text-right">
                <span className="font-mono text-xl font-bold text-cyan-300">
                  {stats.count > 0 ? stats.min.toFixed(1) : '---'}
                </span>
                <span className="font-mono text-xs text-neutral-500 ml-1">V</span>
              </div>
            </div>

            {/* AVG_READING */}
            <div className="bg-neutral-900/40 border border-white/5 p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-mono text-[10px] text-neutral-400 block uppercase tracking-wider">Média de Tensão</span>
                <span className="font-sans text-xs text-neutral-500">Média integrada contínua</span>
              </div>
              <div className="text-right">
                <span className="font-mono text-xl font-bold text-cyan-300">
                  {stats.count > 0 ? stats.avg.toFixed(1) : '---'}
                </span>
                <span className="font-mono text-xs text-neutral-500 ml-1">V</span>
              </div>
            </div>

            {/* MAX_READING */}
            <div className="bg-neutral-900/40 border border-white/5 p-3 rounded flex items-center justify-between">
              <div>
                <span className="font-mono text-[10px] text-neutral-400 block uppercase tracking-wider">Máximo Registrado</span>
                <span className="font-sans text-xs text-neutral-500">Máximo de pico gravado</span>
              </div>
              <div className="text-right">
                <span className="font-mono text-xl font-bold text-purple-400">
                  {stats.count > 0 ? stats.max.toFixed(1) : '---'}
                </span>
                <span className="font-mono text-xs text-neutral-500 ml-1">V</span>
              </div>
            </div>
          </div>
        </div>

        {/* Reset stats button */}
        <button
          id="btn-reset-data"
          onClick={onResetStats}
          className="w-full bg-purple-950/20 hover:bg-purple-900/20 text-purple-400 border border-purple-500/30 hover:border-purple-500 py-3 font-mono font-bold uppercase tracking-wider text-[11px] rounded transition-all active:scale-95 flex items-center justify-center gap-2 mt-6 cursor-pointer"
        >
          <Trash2 className="w-3.5 h-3.5 text-purple-400" />
          Zerar Histórico (RESET_DATA)
        </button>
      </section>

      {/* 3. Analog Indicator Gauge (Row 2, Left Column) */}
      <section id="panel-analog" className="col-span-12 md:col-span-4 glass-panel p-5 flex flex-col justify-between min-h-[220px]">
        <div className="flex justify-between items-center mb-2">
          <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
            SEC_04 // ANALOG_INDICATOR
          </span>
          <BrainCircuit className="w-3.5 h-3.5 text-cyan-400" />
        </div>

        {/* Dynamic Analog Gauge using inline SVG */}
        <div className="flex-grow flex items-center justify-center relative my-2">
          <div className="w-36 h-20 relative">
            <svg viewBox="0 0 100 50" className="w-full h-full">
              {/* Outer scale boundary arc */}
              <path 
                d="M 10 50 A 40 40 0 0 1 90 50" 
                fill="none" 
                stroke="#2a2a2c" 
                strokeWidth="5" 
                strokeLinecap="round"
              />
              
              {/* Green/Cyan safe range segment */}
              <path 
                d="M 10 50 A 40 40 0 0 1 74 20" 
                fill="none" 
                stroke="url(#cyan-gradient)" 
                strokeWidth="5"
                strokeLinecap="butt"
              />

              {/* Red warning range segment */}
              <path 
                d="M 74 20 A 40 40 0 0 1 90 50" 
                fill="none" 
                stroke="#ef4444" 
                strokeWidth="5"
                strokeLinecap="butt"
              />

              {/* Gradients definitions */}
              <defs>
                <linearGradient id="cyan-gradient" x1="0%" y1="100%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#00f2ff" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#a855f7" stopOpacity="0.8" />
                </linearGradient>
              </defs>

              {/* Central Pin */}
              <circle cx="50" cy="50" r="3" fill="#ffffff" />

              {/* Rotating Needle */}
              <line 
                x1="50" 
                y1="50" 
                x2="50" 
                y2="15" 
                stroke={status === 'SURTO_TENSÃO' ? '#ef4444' : '#00f2ff'} 
                strokeWidth="2.5" 
                strokeLinecap="round"
                style={{ 
                  transformOrigin: '50px 50px',
                  transform: `rotate(${needleRotation}deg)`,
                  transition: 'transform 0.1s cubic-bezier(0.18, 0.89, 0.32, 1.28)'
                }}
              />
            </svg>

            {/* Labels beneath needle arc */}
            <span className="absolute left-1 bottom-1 font-mono text-[9px] text-neutral-500">0</span>
            <span className="absolute right-1 bottom-1 font-mono text-[9px] text-neutral-500">300</span>
            <span className="absolute left-1/2 -translate-x-1/2 bottom-0 font-mono text-[10px] text-cyan-400 font-bold bg-neutral-900 border border-neutral-800 px-1.5 rounded">
              {voltage.toFixed(1)}
            </span>
          </div>
        </div>

        <div className="font-mono text-[10px] text-neutral-500 text-center uppercase tracking-wider">
          Indicador Analógico de Ponteiro
        </div>
      </section>

      {/* 4. Reading Log / Log das Leituras (Row 2, Right Column) */}
      <section id="panel-logs" className="col-span-12 md:col-span-8 glass-panel flex flex-col justify-between min-h-[220px] overflow-hidden">
        {/* Header bar with flashing pulse live light */}
        <div className="px-5 py-3 border-b border-white/5 flex justify-between items-center bg-neutral-900/30">
          <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
            SEC_05 // READING_LOG // FREQ: 1HZ
          </span>
          <div className="flex items-center gap-2 font-mono text-[10px]">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 pulse-glow-red shrink-0" />
            <span className="text-red-500 font-bold tracking-wider">LIVE_MONITORING</span>
          </div>
        </div>

        {/* Scrollable Log Lines List */}
        <div className="flex-grow p-4 font-mono text-[11px] space-y-1.5 overflow-y-auto max-h-[140px]">
          {history.length === 0 ? (
            <div className="h-full flex items-center justify-center text-neutral-500 italic text-xs py-6">
              Aguardando primeiras leituras do barramento para preencher o registro...
            </div>
          ) : (
            history.map((log) => (
              <div 
                key={log.index} 
                className="flex items-center justify-between border-b border-white/[0.02] pb-1 hover:bg-white/5 px-1 rounded transition-colors"
              >
                {/* Left side telemetry info */}
                <div className="flex gap-2 items-center flex-wrap">
                  <span className="text-neutral-500">[{padIndex(log.index)}]</span>
                  <span className="text-cyan-400/90 font-bold px-1 rounded bg-neutral-900">
                    {log.voltage.toFixed(1)} V
                  </span>
                  <span className="text-neutral-500">//</span>
                  <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${getStatusBadge(log.status)}`}>
                    {log.status}
                  </span>
                  <span className="text-neutral-500">//</span>
                  <span className="text-neutral-400">DESVIO:</span>
                  <span className={log.deviationPercent >= 0 ? 'text-red-400' : 'text-cyan-400'}>
                    {log.deviationPercent >= 0 ? '+' : ''}{log.deviationPercent}%
                  </span>
                </div>

                {/* Right side timestamp */}
                <div className="text-neutral-500 text-[10px] shrink-0 font-light">
                  {log.timestamp.toLocaleTimeString('pt-BR')}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Total stats bar */}
        <div className="px-4 py-2 border-t border-white/5 bg-neutral-900/10 font-mono text-[10px] text-neutral-400 flex justify-between">
          <span>REGISTROS TOTAIS: {stats.count} leituras</span>
          <span>FILTRO: CORRENTE {mode}</span>
        </div>
      </section>

    </div>
  );
}
