import React, { useState } from 'react';
import { PicoFirmwareType } from '../types';
import { Check, Copy, Code, Terminal, Sparkles } from 'lucide-react';

export default function PicoCodeSnippets() {
  const [copied, setCopied] = useState(false);
  const [selectedFirmware, setSelectedFirmware] = useState<PicoFirmwareType>('micropython');

  const microPythonCode = `# Raspberry Pi Pico - MicroPython
# Script para ler e enviar dados de tensão para o CCETINO Multimeter
import time
import machine
import random # Usado para demonstrar variação se nenhum sensor real estiver lido

# Configura o ADC (conversor analógico-digital) na GP26 (pino 31)
# Se você tiver um divisor de tensão real conectado para medir até 300V
adc = machine.ADC(26)

# Fatores de calibração para seu divisor de tensão
CALIBRATION_FACTOR = 300.0 / 65535.0  # Mapeamento do ADC de 16-bits

mode = "AC"      # "AC" ou "DC"
measure = "Tensão"
max_voltage = 300.0

print("CCETINO // PICO_BOOT_ESTABLISHED")

while True:
    # 1. Lê a porta ADC do Pico
    adc_raw = adc.read_u16()
    
    # 2. Converte para o valor de tensão (0 a 300V)
    # Se testando sem hardware, podemos gerar oscilação senoidal:
    # voltage = 220.0 + 8.0 * random.uniform(-1, 1)
    voltage = adc_raw * CALIBRATION_FACTOR
    
    # Prevenção de picos de ruído e limites
    if voltage < 1.0:
        voltage = 0.0
    if voltage > 300.0:
        voltage = 300.0

    # 3. Formato de envio (CSV simples reconhecido pelo CCETINO)
    # Formato: valor_atual,valor_maximo,AC_DC,medida
    # Exemplo impresso na serial: "234.5,300,AC,Tensão"
    print(f"{voltage:.1f},{max_voltage:.1f},{mode},{measure}")
    
    # O painel aceita atualizações em alta frequência, 
    # mas registra o log no banco exatamente a cada 1 segundo (1Hz).
    time.sleep(0.1) # Envia a cada 100ms para um ponteiro super fluido!
`;

  const arduinoCode = `// Raspberry Pi Pico - Arduino IDE (C++)
// Script para ler e enviar dados de tensão para o CCETINO Multimeter

const int adcPin = 26; // GP26 (Pino analógico A0)
const float maxVoltage = 300.0;
const String mode = "AC"; // Ou "DC"
const String measure = "Tensão";

// Fator para mapear leitura ADC de 10-bits (ou 12-bits no Pico) para 0-300V
// No Pico o Arduino IDE usa resolução de 10-bits por padrão (0-1023) ou 12-bits (0-4095)
const float calibrationFactor = 300.0 / 1023.0; 

void setup() {
  // Inicializa comunicação Serial a 115200 bps
  Serial.begin(115200);
  
  // Configura a resolução ADC para 10-bits (padrão) ou 12-bits se desejado
  analogReadResolution(10); 
  
  pinMode(adcPin, INPUT);
}

void loop() {
  // 1. Lê o canal analógico
  int adcValue = analogRead(adcPin);
  
  // 2. Converte para tensão
  float voltage = adcValue * calibrationFactor;
  
  // Limites seguros
  if (voltage < 0.8) {
    voltage = 0.0;
  }
  if (voltage > 300.0) {
    voltage = 300.0;
  }
  
  // 3. Envia no formato esperado (CSV)
  // Formato enviado: "valor_atual,valor_maximo,AC_DC,medida"
  // Exemplo na Serial: "228.4,300.0,AC,Tensão"
  Serial.print(voltage, 1);
  Serial.print(",");
  Serial.print(maxVoltage, 1);
  Serial.print(",");
  Serial.print(mode);
  Serial.print(",");
  Serial.println(measure);
  
  // Envia frequentemente para atualizar o ponteiro em tempo real.
  // O log do dashboard captura e registra de 1s em 1s.
  delay(100); 
}
`;

  const activeCode = selectedFirmware === 'micropython' ? microPythonCode : arduinoCode;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(activeCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="glass-panel p-6 flex flex-col h-full overflow-hidden">
      <div className="flex justify-between items-center mb-6">
        <div>
          <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest block mb-1">
            Instruções // firmware_pico
          </span>
          <h2 className="font-display text-xl font-semibold text-white">Como programar o seu Raspberry Pi Pico</h2>
        </div>
        <div className="flex items-center gap-2 bg-neutral-900 border border-neutral-800 p-1 rounded font-mono text-xs">
          <button
            onClick={() => setSelectedFirmware('micropython')}
            className={`px-3 py-1.5 rounded transition-all ${
              selectedFirmware === 'micropython'
                ? 'bg-cyan-500/10 text-cyan-400 font-bold border border-cyan-500/20'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            MicroPython
          </button>
          <button
            onClick={() => setSelectedFirmware('arduino')}
            className={`px-3 py-1.5 rounded transition-all ${
              selectedFirmware === 'arduino'
                ? 'bg-cyan-500/10 text-cyan-400 font-bold border border-cyan-500/20'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Arduino (C++)
          </button>
        </div>
      </div>

      <div className="mb-6 text-sm text-neutral-300 space-y-3 font-sans">
        <p>
          O painel <strong className="text-cyan-400 font-medium">CCETINO Multimeter</strong> lê as informações vindas da porta serial USB do Raspberry Pi Pico.
          Para que o sistema consiga interpretar as medições, o seu Pico deve enviar constantemente uma linha contendo as 4 informações separadas por vírgula no formato abaixo:
        </p>
        <div className="p-3 bg-neutral-950 border border-white/5 rounded font-mono text-xs flex flex-wrap gap-2 items-center text-cyan-300">
          <span className="px-1.5 py-0.5 bg-cyan-950 rounded border border-cyan-900 text-cyan-400">Tensão_Atual (0-300)</span>
          <span>,</span>
          <span className="px-1.5 py-0.5 bg-neutral-900 rounded border border-neutral-800 text-purple-400">Tensão_Máxima</span>
          <span>,</span>
          <span className="px-1.5 py-0.5 bg-neutral-900 rounded border border-neutral-800 text-pink-400">"AC" | "DC"</span>
          <span>,</span>
          <span className="px-1.5 py-0.5 bg-neutral-900 rounded border border-neutral-800 text-emerald-400">"Tensão"</span>
        </div>
        <p className="text-xs text-neutral-400 italic">
          💡 Exemplo de linha enviada pela Serial: <code className="text-cyan-400 font-mono">234.5,300.0,AC,Tensão</code>
        </p>
      </div>

      {/* Code Area */}
      <div className="flex-grow flex flex-col relative bg-neutral-950 border border-white/5 rounded overflow-hidden">
        {/* Code Header bar */}
        <div className="px-4 py-2 bg-neutral-900 border-b border-white/5 flex justify-between items-center text-xs font-mono text-neutral-400">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-cyan-400" />
            <span>{selectedFirmware === 'micropython' ? 'main.py' : 'multimeter.ino'}</span>
          </div>
          <button
            onClick={copyToClipboard}
            className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-bold">Copiado!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copiar código</span>
              </>
            )}
          </button>
        </div>

        {/* Code editor body */}
        <div className="flex-grow overflow-auto p-4 font-mono text-[12px] leading-relaxed text-neutral-300">
          <pre>{activeCode}</pre>
        </div>
      </div>

      {/* Hardware Pinouts Help */}
      <div className="mt-4 p-3 bg-cyan-950/20 border border-cyan-500/20 rounded flex items-start gap-3">
        <Sparkles className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="text-xs text-neutral-300 font-mono leading-normal">
          <span className="font-bold text-cyan-400 uppercase block mb-1">Dica de Ligação Física:</span>
          Use a porta analógica <span className="text-white">GP26 (Pino 31)</span> do Raspberry Pi Pico. 
          Use um divisor de tensão seguro (ex: resistores de 1MΩ e 10kΩ) para rebaixar a tensão máxima de 300V para a faixa aceitável pelo pino do Pico (0V a 3.3V). 
          <span className="text-yellow-400 font-bold block mt-1">⚠️ ATENÇÃO: Altas tensões são perigosas. Faça testes primeiro usando simulações ou tensões baixas (pilhas de 1.5V ou 9V) antes de ligar na rede elétrica!</span>
        </div>
      </div>
    </div>
  );
}
