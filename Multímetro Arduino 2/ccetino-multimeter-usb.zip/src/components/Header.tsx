import React, { useEffect, useState } from 'react';
import { ConnectionStatus, ConnectionType } from '../types';
import { ShieldCheck, Cpu, Zap, Radio } from 'lucide-react';

interface HeaderProps {
  connectionStatus: ConnectionStatus;
  connectionType: ConnectionType;
  baudRate: number;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function Header({
  connectionStatus,
  connectionType,
  baudRate,
  activeTab,
  setActiveTab
}: HeaderProps) {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString('pt-BR'));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header id="app-header" className="fixed top-0 left-0 right-0 h-16 z-50 bg-neutral-950/85 backdrop-blur-xl text-primary-fixed-dim border-b border-white/10 shadow-[0_4px_20px_rgba(0,242,255,0.1)] flex justify-between items-center px-6">
      {/* Brand & Version */}
      <div className="flex items-center gap-3">
        <div className="flex items-center justify-center w-8 h-8 rounded border border-cyan-500/30 bg-cyan-500/10">
          <Zap className="w-4 h-4 text-cyan-400 animate-pulse" />
        </div>
        <span className="font-display font-bold text-lg tracking-tight text-white flex items-center gap-1.5">
          CCETINO <span className="text-cyan-400 text-xs font-mono font-medium px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-800/50">MULTIMETER_V.01</span>
        </span>
      </div>

      {/* Tabs */}
      <div className="hidden md:flex items-center gap-6 font-mono text-xs uppercase tracking-wider">
        <button
          id="tab-dashboard"
          onClick={() => setActiveTab('dashboard')}
          className={`px-3 py-1.5 border-b-2 transition-all duration-200 ${
            activeTab === 'dashboard'
              ? 'text-cyan-400 border-cyan-400 font-bold'
              : 'text-neutral-400 border-transparent hover:text-white hover:bg-white/5'
          }`}
        >
          Painel de Controle
        </button>
        <button
          id="tab-simulator"
          onClick={() => setActiveTab('simulator')}
          className={`px-3 py-1.5 border-b-2 transition-all duration-200 ${
            activeTab === 'simulator'
              ? 'text-cyan-400 border-cyan-400 font-bold'
              : 'text-neutral-400 border-transparent hover:text-white hover:bg-white/5'
          }`}
        >
          Configurar Simulador
        </button>
        <button
          id="tab-code"
          onClick={() => setActiveTab('code')}
          className={`px-3 py-1.5 border-b-2 transition-all duration-200 ${
            activeTab === 'code'
              ? 'text-cyan-400 border-cyan-400 font-bold'
              : 'text-neutral-400 border-transparent hover:text-white hover:bg-white/5'
          }`}
        >
          Código Raspberry Pi Pico
        </button>
      </div>

      {/* Telemetry Status Bar */}
      <div className="flex items-center gap-4">
        {/* Connection Mode Indicator */}
        <div className="flex items-center gap-2">
          {connectionStatus === 'connected' ? (
            <div className="bg-cyan-950/70 border border-cyan-500/30 px-3 py-1 flex items-center gap-2 rounded text-cyan-400 shadow-[0_0_10px_rgba(0,242,255,0.15)] relative overflow-hidden">
              <span className="scan-line"></span>
              <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              <span className="font-mono text-[11px] font-bold tracking-wider">
                {connectionType === 'serial' ? `PORTA_USB (${baudRate}bps)` : 'SIMULADOR_ATIVO'}
              </span>
            </div>
          ) : connectionStatus === 'connecting' ? (
            <div className="bg-purple-950/70 border border-purple-500/30 px-3 py-1 flex items-center gap-2 rounded text-purple-400 animate-pulse">
              <Cpu className="w-3.5 h-3.5 text-purple-400 animate-spin" />
              <span className="font-mono text-[11px] font-bold tracking-wider">CONECTANDO...</span>
            </div>
          ) : (
            <div className="bg-neutral-900 border border-neutral-700 px-3 py-1 flex items-center gap-2 rounded text-neutral-400">
              <span className="w-1.5 h-1.5 rounded-full bg-neutral-600"></span>
              <span className="font-mono text-[11px] tracking-wider">USB DESCONECTADA</span>
            </div>
          )}
        </div>

        {/* Dynamic Clock Display */}
        <div className="hidden sm:flex items-center gap-1.5 bg-neutral-900 border border-neutral-800 px-3 py-1 rounded text-neutral-300 font-mono text-xs">
          <span className="text-neutral-500 font-sans">GMT-3</span>
          <span className="text-cyan-400/90 font-bold">{time}</span>
        </div>
      </div>
    </header>
  );
}
