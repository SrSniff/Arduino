import React from 'react';
import { ConnectionStatus, ConnectionType } from '../types';
import { 
  Activity, 
  Terminal, 
  Sliders, 
  Code, 
  Power, 
  AlertCircle,
  HelpCircle,
  Usb,
  Wifi
} from 'lucide-react';

interface SidebarProps {
  connectionStatus: ConnectionStatus;
  connectionType: ConnectionType;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onConnectSerial: () => void;
  onConnectSimulator: () => void;
  onDisconnect: () => void;
  serialError: string | null;
}

export default function Sidebar({
  connectionStatus,
  connectionType,
  activeTab,
  setActiveTab,
  onConnectSerial,
  onConnectSimulator,
  onDisconnect,
  serialError
}: SidebarProps) {
  return (
    <aside id="app-sidebar" className="fixed left-0 top-0 h-full w-64 z-40 bg-neutral-950/90 backdrop-blur-md border-r border-white/10 flex flex-col pt-20 pb-6">
      {/* Operator Profile */}
      <div className="px-6 mb-6">
        <div className="flex items-center gap-3 p-3 rounded bg-neutral-900/60 border border-white/5">
          <div className="w-10 h-10 rounded bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center overflow-hidden">
            <img 
              className="w-full h-full object-cover" 
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuD5SmA0c9WCh09dNhpyItDKM3kJs5LbM8xq6muMzbw7xOuRBRzebp_L6BYkV3l41v6XxNToKikLP3jZysAd8DA7QA7g8RBES6CSeXKJyc0QiS7afBkRQGkNdYuYylMRGjmJjsFq9ew3biyMX4GMI_oUKeI3PTW8wQW2Eaw-fP0X0IMEi_EOK8x4sScF2kSxIVa76qVZNEJYeSyNerOwH9YwN9OP-ApLYv7TJyFajO2M9AsX42SLA7nF" 
              alt="Operador Daniel Scherer"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="font-display font-semibold text-sm text-cyan-100 leading-tight">Daniel Scherer</div>
            <div className="font-mono text-[9px] mt-0.5 tracking-wider flex items-center gap-1">
              <span className={`w-1.5 h-1.5 rounded-full ${
                connectionStatus === 'connected' 
                  ? 'bg-cyan-400 animate-pulse' 
                  : connectionStatus === 'connecting' 
                    ? 'bg-purple-400 animate-ping' 
                    : 'bg-red-500'
              }`}></span>
              <span className="text-neutral-400">
                {connectionStatus === 'connected' 
                  ? (connectionType === 'serial' ? 'CONECTADO USB' : 'SIMULANDO') 
                  : connectionStatus === 'connecting' 
                    ? 'CONECTANDO...' 
                    : 'DESCONECTADO'}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex-grow flex flex-col gap-1 font-mono text-xs tracking-wider">
        <button
          id="menu-dashboard"
          onClick={() => setActiveTab('dashboard')}
          className={`px-6 py-3.5 flex items-center gap-3 transition-all border-l-4 ${
            activeTab === 'dashboard'
              ? 'bg-cyan-500/10 text-cyan-400 border-cyan-400 font-bold'
              : 'text-neutral-400 border-transparent hover:bg-neutral-900/50 hover:text-white'
          }`}
        >
          <Activity className="w-4 h-4 text-cyan-400" />
          <span>VOLTÍMETRO</span>
        </button>

        <button
          id="menu-simulator"
          onClick={() => setActiveTab('simulator')}
          className={`px-6 py-3.5 flex items-center gap-3 transition-all border-l-4 ${
            activeTab === 'simulator'
              ? 'bg-cyan-500/10 text-cyan-400 border-cyan-400 font-bold'
              : 'text-neutral-400 border-transparent hover:bg-neutral-900/50 hover:text-white'
          }`}
        >
          <Sliders className="w-4 h-4 text-purple-400" />
          <span>SIMULADOR PICO</span>
        </button>

        <button
          id="menu-code"
          onClick={() => setActiveTab('code')}
          className={`px-6 py-3.5 flex items-center gap-3 transition-all border-l-4 ${
            activeTab === 'code'
              ? 'bg-cyan-500/10 text-cyan-400 border-cyan-400 font-bold'
              : 'text-neutral-400 border-transparent hover:bg-neutral-900/50 hover:text-white'
          }`}
        >
          <Code className="w-4 h-4 text-emerald-400" />
          <span>CÓDIGO FONTE PICO</span>
        </button>
      </nav>

      {/* Bottom Action Section */}
      <div className="px-6 mt-auto">
        {serialError && (
          <div className="mb-4 p-2 bg-red-950/80 border border-red-500/30 rounded text-[10px] text-red-300 font-mono leading-tight flex gap-1.5 items-start">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 text-red-400" />
            <div>
              <span className="font-bold text-red-400 uppercase block mb-0.5">Erro de Conexão</span>
              {serialError}
            </div>
          </div>
        )}

        {connectionStatus === 'connected' ? (
          <button
            id="btn-disconnect"
            onClick={onDisconnect}
            className="w-full bg-red-950/40 hover:bg-red-900/60 text-red-400 hover:text-red-200 border border-red-500/40 hover:border-red-500 py-3 font-mono font-bold uppercase tracking-widest text-[11px] rounded transition-all active:scale-95 flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(239,68,68,0.05)] cursor-pointer"
          >
            <Power className="w-3.5 h-3.5 text-red-400 animate-pulse" />
            DESCONECTAR
          </button>
        ) : (
          <div className="flex flex-col gap-2">
            {/* Primary Action: Read Real USB */}
            <button
              id="btn-connect-usb"
              onClick={onConnectSerial}
              className="w-full bg-cyan-400 hover:bg-cyan-300 text-neutral-950 py-3 font-mono font-bold uppercase tracking-widest text-[11px] rounded transition-all active:scale-95 flex items-center justify-center gap-2 btn-primary-glow cursor-pointer"
            >
              <Usb className="w-4 h-4 text-neutral-950" />
              CONECTAR USB
            </button>

            {/* Quick Simulation Trigger */}
            <button
              id="btn-connect-sim"
              onClick={onConnectSimulator}
              className="w-full bg-neutral-900 hover:bg-neutral-800 text-purple-400 border border-purple-500/30 py-2.5 font-mono font-bold uppercase tracking-wider text-[10px] rounded transition-all active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Wifi className="w-3.5 h-3.5 text-purple-400" />
              ATIVAR SIMULADOR
            </button>
          </div>
        )}

        {/* Shutdown reference */}
        <div className="mt-5 flex items-center justify-center gap-2 text-neutral-500 hover:text-neutral-300 font-mono text-[10px] uppercase tracking-wider cursor-pointer transition-colors">
          <Power className="w-3 h-3 text-neutral-500" />
          <span>Fim de Sessão</span>
        </div>
      </div>
    </aside>
  );
}
