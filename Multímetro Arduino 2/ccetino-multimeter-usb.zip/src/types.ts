export type ConnectionStatus = 'disconnected' | 'connecting' | 'connected';
export type ConnectionType = 'serial' | 'simulator';

export interface Reading {
  voltage: number;
  voltageMax: number;
  mode: 'AC' | 'DC';
  measure: string;
  timestamp: Date;
  index: number;
  status: 'NOMINAL' | 'ALERTA' | 'SURTO_TENSÃO' | 'SOBRETENSÃO' | 'SUBTENSÃO';
  deviationPercent: number;
}

export interface Stats {
  min: number;
  max: number;
  avg: number;
  count: number;
  sum: number;
}

export type PicoFirmwareType = 'micropython' | 'arduino';
