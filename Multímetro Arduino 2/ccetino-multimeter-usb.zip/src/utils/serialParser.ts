import { Reading } from '../types';

/**
 * Parses a single line received from the Raspberry Pi Pico.
 * Supports CSV, JSON, and custom Key-Value formats.
 * Falls back to defaults if any values are missing or malformed.
 */
export function parseSerialLine(line: string, index: number, runningAvg: number = 220): Reading {
  const cleanLine = line.trim();
  const now = new Date();
  
  // Default values
  let voltage = 0;
  let voltageMax = 300;
  let mode: 'AC' | 'DC' = 'AC';
  let measure = 'Tensão';

  if (!cleanLine) {
    return createReadingObject(0, 300, 'AC', 'Tensão', index, now, runningAvg);
  }

  // Attempt 1: JSON Parsing
  try {
    if (cleanLine.startsWith('{') && cleanLine.endsWith('}')) {
      const data = JSON.parse(cleanLine);
      
      // Handle English/Code fields or Portuguese fields
      voltage = parseFloat(data.voltage ?? data.valor ?? data.value ?? 0);
      voltageMax = parseFloat(data.voltageMax ?? data.max ?? data.valorMaximo ?? 300);
      
      const rawMode = (data.mode ?? data.tipo ?? data.mode_type ?? 'AC').toUpperCase();
      mode = rawMode.includes('DC') ? 'DC' : 'AC';
      
      measure = data.measure ?? data.medida ?? data.label ?? 'Tensão';

      return createReadingObject(voltage, voltageMax, mode, measure, index, now, runningAvg);
    }
  } catch (e) {
    // Fail-safe to next parsers
  }

  // Attempt 2: CSV Parsing (comma, semicolon, or tab)
  const delimiter = cleanLine.includes(';') ? ';' : cleanLine.includes('\t') ? '\t' : ',';
  const parts = cleanLine.split(delimiter).map(p => p.trim());

  if (parts.length >= 2 && !isNaN(parseFloat(parts[0]))) {
    voltage = parseFloat(parts[0]);
    voltageMax = parseFloat(parts[1]);
    
    if (parts.length >= 3) {
      const rawMode = parts[2].toUpperCase();
      mode = rawMode.includes('DC') ? 'DC' : 'AC';
    }
    
    if (parts.length >= 4) {
      measure = parts[3];
    }

    return createReadingObject(voltage, voltageMax, mode, measure, index, now, runningAvg);
  }

  // Attempt 3: Key-Value format (e.g., V=234.5;MAX=300;MODE=AC;MEASURE=Tensão)
  const kvPairs = cleanLine.split(/[;,&]/);
  let parsedKv = false;
  
  kvPairs.forEach(pair => {
    const [key, val] = pair.split('=').map(p => p.trim().toLowerCase());
    if (key && val) {
      parsedKv = true;
      if (key === 'v' || key === 'voltage' || key === 'valor' || key === 'tension' || key === 'tensao') {
        voltage = parseFloat(val);
      } else if (key === 'max' || key === 'maximum' || key === 'lim' || key === 'limite') {
        voltageMax = parseFloat(val);
      } else if (key === 'mode' || key === 'tipo' || key === 'corrente') {
        mode = val.toUpperCase().includes('DC') ? 'DC' : 'AC';
      } else if (key === 'measure' || key === 'medida' || key === 'unidade') {
        measure = val;
      }
    }
  });

  if (parsedKv && !isNaN(voltage)) {
    return createReadingObject(voltage, voltageMax, mode, measure, index, now, runningAvg);
  }

  // Attempt 4: Single float value format
  const singleValue = parseFloat(cleanLine);
  if (!isNaN(singleValue)) {
    voltage = singleValue;
    return createReadingObject(voltage, 300, 'AC', 'Tensão', index, now, runningAvg);
  }

  // Final fallback (could not parse properly)
  return createReadingObject(0, 300, 'AC', 'Tensão', index, now, runningAvg);
}

function createReadingObject(
  voltage: number,
  voltageMax: number,
  mode: 'AC' | 'DC',
  measure: string,
  index: number,
  timestamp: Date,
  runningAvg: number
): Reading {
  // Safe bounds check
  if (isNaN(voltage)) voltage = 0;
  if (isNaN(voltageMax) || voltageMax <= 0) voltageMax = 300;

  // Classify reading status
  let status: Reading['status'] = 'NOMINAL';
  
  // Calculate difference from running average or typical nominal (like 127V / 220V)
  const isZero = voltage < 0.5;
  const devPercent = isZero ? 0 : runningAvg > 0 ? ((voltage - runningAvg) / runningAvg) * 100 : 0;

  if (voltage > voltageMax * 0.95) {
    status = 'SURTO_TENSÃO';
  } else if (voltage > runningAvg * 1.15 && !isZero) {
    status = 'SOBRETENSÃO';
  } else if (voltage < runningAvg * 0.85 && !isZero && voltage > 5) {
    status = 'SUBTENSÃO';
  } else if (voltage > voltageMax * 0.85) {
    status = 'ALERTA';
  }

  return {
    voltage,
    voltageMax,
    mode,
    measure,
    timestamp,
    index,
    status,
    deviationPercent: parseFloat(devPercent.toFixed(2))
  };
}
