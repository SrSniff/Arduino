import React, { useState, useEffect, useRef } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MainDashboard from './components/MainDashboard';
import SimulationControls from './components/SimulationControls';
import PicoCodeSnippets from './components/PicoCodeSnippets';
import { ConnectionStatus, ConnectionType, Reading, Stats } from './types';
import { parseSerialLine } from './utils/serialParser';
import { ShieldCheck, HelpCircle } from 'lucide-react';

export default function App() {
  // Navigation
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Connection State
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [connectionType, setConnectionType] = useState<ConnectionType>('simulator');
  const [serialError, setSerialError] = useState<string | null>(null);
  const [baudRate] = useState<number>(115200);

  // Simulation controls state
  const [simNominal, setSimNominal] = useState<number>(220);
  const [simMax, setSimMax] = useState<number>(300);
  const [simMode, setSimMode] = useState<'AC' | 'DC'>('AC');
  const [simFluctuation, setSimFluctuation] = useState<'none' | 'low' | 'high'>('low');

  // Interactive spike/drop overrides (null if none)
  const [overrideValue, setOverrideValue] = useState<number | null>(null);

  // Current real-time reading state
  const [currentReading, setCurrentReading] = useState<Reading>({
    voltage: 0,
    voltageMax: 300,
    mode: 'AC',
    measure: 'Tensão',
    timestamp: new Date(),
    index: 0,
    status: 'NOMINAL',
    deviationPercent: 0
  });

  // Log history registered EXACTLY every 1 second (1Hz)
  const [history, setHistory] = useState<Reading[]>([]);

  // Integrated Statistics
  const [stats, setStats] = useState<Stats>({
    min: 0,
    max: 0,
    avg: 0,
    count: 0,
    sum: 0
  });

  // Refs for background thread & stream control
  const serialPortRef = useRef<any>(null);
  const readerRef = useRef<any>(null);
  const simIntervalRef = useRef<any>(null);
  const currentReadingRef = useRef<Reading>(currentReading);

  // Sync ref with state so interval captures latest value
  useEffect(() => {
    currentReadingRef.current = currentReading;
  }, [currentReading]);

  // Keep track of average to feed to parser for deviations
  const runningAvg = stats.count > 0 ? stats.avg : simNominal;

  // Real-time parser receiver
  const handleIncomingSerialLine = (line: string) => {
    try {
      const parsed = parseSerialLine(line, currentReadingRef.current.index + 1, runningAvg);
      setCurrentReading(parsed);
    } catch (e) {
      console.error("Erro ao analisar linha serial:", e);
    }
  };

  // 1. Connection Handlers: Connect Real USB Port (Web Serial API)
  const handleConnectSerial = async () => {
    setSerialError(null);
    setConnectionStatus('connecting');

    // Turn off any simulation
    if (simIntervalRef.current) {
      clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    try {
      if (!('serial' in navigator)) {
        throw new Error("A API Web Serial não é suportada por este navegador. Certifique-se de que está usando o Google Chrome, Edge ou Opera!");
      }

      // Request port from user
      const port = await (navigator as any).serial.requestPort();
      
      // Open port with 115200 bps
      await port.open({ baudRate });

      setConnectionStatus('connected');
      setConnectionType('serial');
      serialPortRef.current = port;

      // Start stream reader loop
      readSerialStream(port);
    } catch (err: any) {
      console.error(err);
      setSerialError(err.message || "Usuário cancelou ou falhou em obter permissão para a porta USB.");
      setConnectionStatus('disconnected');
    }
  };

  // Async loop to stream data from USB Port
  const readSerialStream = async (port: any) => {
    const textDecoder = new TextDecoderStream();
    const readableStreamClosed = port.readable.pipeTo(textDecoder.writable);
    const reader = textDecoder.readable.getReader();

    readerRef.current = reader;

    let buffer = '';
    try {
      while (true) {
        const { value, done } = await reader.read();
        if (done) {
          break;
        }
        if (value) {
          buffer += value;
          const lines = buffer.split(/\r?\n/);
          // Keep last incomplete segment
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.trim()) {
              handleIncomingSerialLine(line);
            }
          }
        }
      }
    } catch (err: any) {
      console.error("Falha ao ler stream serial:", err);
      setSerialError("A conexão USB com o Pico foi perdida.");
      setConnectionStatus('disconnected');
    } finally {
      reader.releaseLock();
    }
  };

  // 2. Connection Handlers: Simulator Loop (Generates realistic Pico data)
  const handleConnectSimulator = () => {
    setSerialError(null);
    setConnectionStatus('connecting');

    // Close any real USB ports
    if (serialPortRef.current) {
      try {
        serialPortRef.current.close();
      } catch (e) {}
      serialPortRef.current = null;
    }

    // Set simulator loop
    setTimeout(() => {
      setConnectionStatus('connected');
      setConnectionType('simulator');
      
      if (simIntervalRef.current) {
        clearInterval(simIntervalRef.current);
      }

      // Simulator transmits at 10Hz (every 100ms) for ultra-smooth rendering
      simIntervalRef.current = setInterval(() => {
        let baseVolts = simNominal;

        // Apply interactive override (spike / drop)
        if (overrideValue !== null) {
          baseVolts = overrideValue;
        } else {
          // Apply standard fluctuation noise
          if (simFluctuation === 'low') {
            baseVolts += (Math.random() - 0.5) * 2.5; // +/- 1.25V fluctuation
          } else if (simFluctuation === 'high') {
            baseVolts += (Math.random() - 0.5) * 12.0; // +/- 6V heavy fluctuation
          }
          // clamp to 0 - 300V range
          baseVolts = Math.min(300, Math.max(0, baseVolts));
        }

        // Format CSV payload exactly like the Pico would send over USB
        const mockLine = `${baseVolts.toFixed(1)},${simMax.toFixed(1)},${simMode},Tensão`;
        
        // Handle incoming CSV line
        try {
          const parsed = parseSerialLine(mockLine, currentReadingRef.current.index + 1, runningAvg);
          setCurrentReading(parsed);
        } catch (e) {}
      }, 100);
    }, 500);
  };

  // 3. Disconnect handler
  const handleDisconnect = async () => {
    setConnectionStatus('disconnected');
    
    if (simIntervalRef.current) {
      clearInterval(simIntervalRef.current);
      simIntervalRef.current = null;
    }

    if (readerRef.current) {
      try {
        await readerRef.current.cancel();
      } catch (e) {}
      readerRef.current = null;
    }

    if (serialPortRef.current) {
      try {
        await serialPortRef.current.close();
      } catch (e) {}
      serialPortRef.current = null;
    }

    // Reset current reading
    setCurrentReading({
      voltage: 0,
      voltageMax: 300,
      mode: 'AC',
      measure: 'Tensão',
      timestamp: new Date(),
      index: 0,
      status: 'NOMINAL',
      deviationPercent: 0
    });
  };

  // 1Hz Interval Logger: Appends latest currentReading to history list every 1.0 seconds
  useEffect(() => {
    let logInterval: any = null;

    if (connectionStatus === 'connected') {
      logInterval = setInterval(() => {
        const latest = { ...currentReadingRef.current };
        
        // Skip log if no voltage activity (disconnected)
        if (latest.voltage === 0 && latest.index === 0) return;

        // Increment history list
        setHistory(prev => {
          const nextIndex = prev.length > 0 ? prev[0].index + 1 : 1;
          const newLog: Reading = {
            ...latest,
            timestamp: new Date(),
            index: nextIndex
          };

          // Update aggregated statistics with this 1Hz logged sample
          setStats(prevStats => {
            const nextCount = prevStats.count + 1;
            const nextSum = prevStats.sum + newLog.voltage;
            return {
              min: prevStats.count === 0 ? newLog.voltage : Math.min(prevStats.min, newLog.voltage),
              max: prevStats.count === 0 ? newLog.voltage : Math.max(prevStats.max, newLog.voltage),
              avg: nextSum / nextCount,
              count: nextCount,
              sum: nextSum
            };
          });

          return [newLog, ...prev].slice(0, 100); // keep max 100 elements in memory
        });
      }, 1000);
    } else {
      if (logInterval) clearInterval(logInterval);
    }

    return () => {
      if (logInterval) clearInterval(logInterval);
    };
  }, [connectionStatus]);

  // Handler for Spike/Drop triggers with decay duration of 1.5 seconds
  const handleTriggerSpike = () => {
    setOverrideValue(simNominal * 1.25); // +25% Spike
    setTimeout(() => {
      setOverrideValue(null);
    }, 1500);
  };

  const handleTriggerDrop = () => {
    setOverrideValue(simNominal * 0.70); // -30% Drop
    setTimeout(() => {
      setOverrideValue(null);
    }, 1500);
  };

  const handleResetStats = () => {
    setStats({
      min: 0,
      max: 0,
      avg: 0,
      count: 0,
      sum: 0
    });
    setHistory([]);
  };

  // Auto boot into simulation mode so user sees beautiful active data instantly
  useEffect(() => {
    handleConnectSimulator();
    return () => {
      if (simIntervalRef.current) clearInterval(simIntervalRef.current);
    };
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 bg-grid-pattern scanlines font-sans">
      
      {/* Dynamic Header */}
      <Header
        connectionStatus={connectionStatus}
        connectionType={connectionType}
        baudRate={baudRate}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Cyber Sidebar */}
      <Sidebar
        connectionStatus={connectionStatus}
        connectionType={connectionType}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onConnectSerial={handleConnectSerial}
        onConnectSimulator={handleConnectSimulator}
        onDisconnect={handleDisconnect}
        serialError={serialError}
      />

      {/* Main Container */}
      <main className="pl-64 pt-16 min-h-screen flex flex-col justify-between">
        <div className="p-6 flex-grow">
          {activeTab === 'dashboard' && (
            <MainDashboard
              currentReading={currentReading}
              stats={stats}
              history={history}
              onResetStats={handleResetStats}
              nominalVoltage={simNominal}
            />
          )}

          {activeTab === 'simulator' && (
            <SimulationControls
              simNominal={simNominal}
              setSimNominal={setSimNominal}
              simMax={simMax}
              setSimMax={setSimMax}
              simMode={simMode}
              setSimMode={setSimMode}
              simFluctuation={simFluctuation}
              setSimFluctuation={setSimFluctuation}
              onTriggerSpike={handleTriggerSpike}
              onTriggerDrop={handleTriggerDrop}
              onResetStats={handleResetStats}
            />
          )}

          {activeTab === 'code' && (
            <PicoCodeSnippets />
          )}
        </div>

        {/* Global footer bar */}
        <footer className="h-10 bg-neutral-950 border-t border-white/5 px-6 flex justify-between items-center font-mono text-[10px] text-cyan-400">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
            <span>SYS_REF: 0xCF44 // PROBE_LINK_ESTABLISHED</span>
          </div>
          <div className="flex gap-4">
            <span className="hover:text-white cursor-pointer flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              PROTOCOLO_SEGURANÇA_ATIVO
            </span>
            <span className="hover:text-white cursor-pointer flex items-center gap-1">
              <HelpCircle className="w-3.5 h-3.5" />
              AJUDA_HARDWARE
            </span>
          </div>
        </footer>
      </main>

    </div>
  );
}
